#include <stdint.h>
typedef uint8_t byte;
byte * aes(byte *in, byte *key1, byte *key2);
void addRoundKey(byte state[16], byte key[16]);
void subBytes(byte state[16], byte key[16]);
void shiftRows(byte state[16], byte key[16]);
byte xtime(byte x);
void mixColumns(byte state[16], byte key[16]);
void computeKey(byte rcon, byte key[16]);
