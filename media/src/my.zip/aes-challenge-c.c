/*
    This file is part of the AESExplorer Example Targets
    Copyright (C) 2012 Colin O'Flynn <coflynn@newae.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdlib.h>
#include <util/delay.h>

#include "aes-challenge.h"

/* WARNING: Be VERY CAREFUL includinf a c-file like this. You are likely to get variable name collisions,
            so suggest to avoid using any generic variable names within this file */
#include "aes_sbox.c"
#include "aes_enc.c"
#include "aes_keyschedule.c"
#include "aes128_enc.c"

aes128_ctx_t ctx;

void aes_indep_init(void)
{
	;
}

void aes_indep_key(uint8_t * key)
{
	aes128_init(key, &ctx);
}

void aes_indep_enc(uint8_t * pt)
{
    /* Jitter-bug implementation - just delay between 0-2000 cycles... lots of issues here.... */
    uint16_t rand_delay = rand() % 2000;
    
    uint16_t i;
    while(i < rand_delay){
        i++;
    }

	aes128_enc(pt, &ctx); /* encrypting the data block */
}
