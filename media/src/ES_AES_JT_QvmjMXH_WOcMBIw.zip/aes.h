#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
typedef uint8_t byte;
void AES_Key_Gen(unsigned char RKey[11][16], unsigned char MKey[16]);
void add_RKey(unsigned char data[], unsigned char RKey[],uint8_t seed_n);
void sub_Bytes(unsigned char data[], unsigned int option,uint8_t seed_n);
void shift_Rows(unsigned char data[],uint8_t seed_n);
void shift_Rows_bertoni(unsigned char data[],uint8_t seed_n);
unsigned char xtime(unsigned char data);
void mix_Columns(unsigned char data[],uint8_t seed_n);
void mix_Columns_bertoni(unsigned char data[],uint8_t seed_n);
void transpose(unsigned char data[]);
void round_function(unsigned char T[], unsigned char CT[],uint8_t seed_n);
void AES_encrypt_original1(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16],uint8_t seed_n);
void AES_encrypt_original1_Macro(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16],uint8_t seed_n);
void AES_encrypt_original2(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16],uint8_t seed_n);
void AES_encrypt_original2_Macro(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16],uint8_t seed_n);
void AES_encrypt_Ttable(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16],uint8_t seed_n);
void AES_encrypt_Ttable_Macro(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16],uint8_t seed_n);
void AES_encrypt_bertoni(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16],uint8_t seed_n);
void AES_encrypt_bertoni_Macro(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16],uint8_t seed_n);
void AES_encrypt_shuffle(unsigned char *PT,unsigned char *RKey[16],unsigned char *CT,uint8_t seed_n);