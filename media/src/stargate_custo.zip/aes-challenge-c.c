/*

Side-channel protected AES-128 by Bart

- Countermeasures: random shuffling computation, masked computation, dummy computation with fake key but real plaintext

*/

#include "aes-challenge.h"

/* comment define for usual C or uncomment for ATMEL C */
#define ATMEL_C

const uint8_t sbox_times[3][256] = {
    /* S-box times 1 lookup table */
{   0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16 },

    /* S-box times 2 lookup table */
{   0xc6, 0xf8, 0xee, 0xf6, 0xff, 0xd6, 0xde, 0x91, 0x60, 0x02, 0xce, 0x56, 0xe7, 0xb5, 0x4d, 0xec,
    0x8f, 0x1f, 0x89, 0xfa, 0xef, 0xb2, 0x8e, 0xfb, 0x41, 0xb3, 0x5f, 0x45, 0x23, 0x53, 0xe4, 0x9b,
    0x75, 0xe1, 0x3d, 0x4c, 0x6c, 0x7e, 0xf5, 0x83, 0x68, 0x51, 0xd1, 0xf9, 0xe2, 0xab, 0x62, 0x2a,
    0x08, 0x95, 0x46, 0x9d, 0x30, 0x37, 0x0a, 0x2f, 0x0e, 0x24, 0x1b, 0xdf, 0xcd, 0x4e, 0x7f, 0xea,
    0x12, 0x1d, 0x58, 0x34, 0x36, 0xdc, 0xb4, 0x5b, 0xa4, 0x76, 0xb7, 0x7d, 0x52, 0xdd, 0x5e, 0x13,
    0xa6, 0xb9, 0x00, 0xc1, 0x40, 0xe3, 0x79, 0xb6, 0xd4, 0x8d, 0x67, 0x72, 0x94, 0x98, 0xb0, 0x85,
    0xbb, 0xc5, 0x4f, 0xed, 0x86, 0x9a, 0x66, 0x11, 0x8a, 0xe9, 0x04, 0xfe, 0xa0, 0x78, 0x25, 0x4b,
    0xa2, 0x5d, 0x80, 0x05, 0x3f, 0x21, 0x70, 0xf1, 0x63, 0x77, 0xaf, 0x42, 0x20, 0xe5, 0xfd, 0xbf,
    0x81, 0x18, 0x26, 0xc3, 0xbe, 0x35, 0x88, 0x2e, 0x93, 0x55, 0xfc, 0x7a, 0xc8, 0xba, 0x32, 0xe6,
    0xc0, 0x19, 0x9e, 0xa3, 0x44, 0x54, 0x3b, 0x0b, 0x8c, 0xc7, 0x6b, 0x28, 0xa7, 0xbc, 0x16, 0xad,
    0xdb, 0x64, 0x74, 0x14, 0x92, 0x0c, 0x48, 0xb8, 0x9f, 0xbd, 0x43, 0xc4, 0x39, 0x31, 0xd3, 0xf2,
    0xd5, 0x8b, 0x6e, 0xda, 0x01, 0xb1, 0x9c, 0x49, 0xd8, 0xac, 0xf3, 0xcf, 0xca, 0xf4, 0x47, 0x10,
    0x6f, 0xf0, 0x4a, 0x5c, 0x38, 0x57, 0x73, 0x97, 0xcb, 0xa1, 0xe8, 0x3e, 0x96, 0x61, 0x0d, 0x0f,
    0xe0, 0x7c, 0x71, 0xcc, 0x90, 0x06, 0xf7, 0x1c, 0xc2, 0x6a, 0xae, 0x69, 0x17, 0x99, 0x3a, 0x27,
    0xd9, 0xeb, 0x2b, 0x22, 0xd2, 0xa9, 0x07, 0x33, 0x2d, 0x3c, 0x15, 0xc9, 0x87, 0xaa, 0x50, 0xa5,
    0x03, 0x59, 0x09, 0x1a, 0x65, 0xd7, 0x84, 0xd0, 0x82, 0x29, 0x5a, 0x1e, 0x7b, 0xa8, 0x6d, 0x2c },

    /* S-box times 3 lookup table */
{   0xa5, 0x84, 0x99, 0x8d, 0x0d, 0xbd, 0xb1, 0x54, 0x50, 0x03, 0xa9, 0x7d, 0x19, 0x62, 0xe6, 0x9a,
    0x45, 0x9d, 0x40, 0x87, 0x15, 0xeb, 0xc9, 0x0b, 0xec, 0x67, 0xfd, 0xea, 0xbf, 0xf7, 0x96, 0x5b,
    0xc2, 0x1c, 0xae, 0x6a, 0x5a, 0x41, 0x02, 0x4f, 0x5c, 0xf4, 0x34, 0x08, 0x93, 0x73, 0x53, 0x3f,
    0x0c, 0x52, 0x65, 0x5e, 0x28, 0xa1, 0x0f, 0xb5, 0x09, 0x36, 0x9b, 0x3d, 0x26, 0x69, 0xcd, 0x9f,
    0x1b, 0x9e, 0x74, 0x2e, 0x2d, 0xb2, 0xee, 0xfb, 0xf6, 0x4d, 0x61, 0xce, 0x7b, 0x3e, 0x71, 0x97,
    0xf5, 0x68, 0x00, 0x2c, 0x60, 0x1f, 0xc8, 0xed, 0xbe, 0x46, 0xd9, 0x4b, 0xde, 0xd4, 0xe8, 0x4a,
    0x6b, 0x2a, 0xe5, 0x16, 0xc5, 0xd7, 0x55, 0x94, 0xcf, 0x10, 0x06, 0x81, 0xf0, 0x44, 0xba, 0xe3,
    0xf3, 0xfe, 0xc0, 0x8a, 0xad, 0xbc, 0x48, 0x04, 0xdf, 0xc1, 0x75, 0x63, 0x30, 0x1a, 0x0e, 0x6d,
    0x4c, 0x14, 0x35, 0x2f, 0xe1, 0xa2, 0xcc, 0x39, 0x57, 0xf2, 0x82, 0x47, 0xac, 0xe7, 0x2b, 0x95,
    0xa0, 0x98, 0xd1, 0x7f, 0x66, 0x7e, 0xab, 0x83, 0xca, 0x29, 0xd3, 0x3c, 0x79, 0xe2, 0x1d, 0x76,
    0x3b, 0x56, 0x4e, 0x1e, 0xdb, 0x0a, 0x6c, 0xe4, 0x5d, 0x6e, 0xef, 0xa6, 0xa8, 0xa4, 0x37, 0x8b,
    0x32, 0x43, 0x59, 0xb7, 0x8c, 0x64, 0xd2, 0xe0, 0xb4, 0xfa, 0x07, 0x25, 0xaf, 0x8e, 0xe9, 0x18,
    0xd5, 0x88, 0x6f, 0x72, 0x24, 0xf1, 0xc7, 0x51, 0x23, 0x7c, 0x9c, 0x21, 0xdd, 0xdc, 0x86, 0x85,
    0x90, 0x42, 0xc4, 0xaa, 0xd8, 0x05, 0x01, 0x12, 0xa3, 0x5f, 0xf9, 0xd0, 0x91, 0x58, 0x27, 0xb9,
    0x38, 0x13, 0xb3, 0x33, 0xbb, 0x70, 0x89, 0xa7, 0xb6, 0x22, 0x92, 0x20, 0x49, 0xff, 0x78, 0x7a,
    0x8f, 0xf8, 0x80, 0x17, 0xda, 0x31, 0xc6, 0xb8, 0xc3, 0xb0, 0x77, 0x11, 0xcb, 0xfc, 0xd6, 0x3a }
};

const uint8_t sPtr[4][24] = {
    /* ShiftRows pointer lookup table */
{   0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17 },
{   0x00, 0x05, 0x0a, 0x0f, 0x04, 0x09, 0x0e, 0x03, 0x08, 0x0d, 0x02, 0x07, 0x0c, 0x01, 0x06, 0x0b, 0x10, 0x15, 0x16, 0x17, 0x14, 0x11, 0x12, 0x13 },
{   0x00, 0x09, 0x02, 0x0b, 0x04, 0x0d, 0x06, 0x0f, 0x08, 0x01, 0x0a, 0x03, 0x0c, 0x05, 0x0e, 0x07, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17 },
{   0x00, 0x0d, 0x0a, 0x07, 0x04, 0x01, 0x0e, 0x0b, 0x08, 0x05, 0x02, 0x0f, 0x0c, 0x09, 0x06, 0x03, 0x10, 0x15, 0x16, 0x17, 0x14, 0x11, 0x12, 0x13 }
};

const uint8_t mPtr[2][24] = {
    /* MixColumns pointer lookup table */
{   0x01, 0x02, 0x03, 0x00, 0x05, 0x06, 0x07, 0x04, 0x09, 0x0a, 0x0b, 0x08, 0x0d, 0x0e, 0x0f, 0x0c, 0x01, 0x02, 0x03, 0x00, 0x05, 0x06, 0x07, 0x04 },
{   0x02, 0x03, 0x00, 0x01, 0x06, 0x07, 0x04, 0x05, 0x0a, 0x0b, 0x08, 0x09, 0x0e, 0x0f, 0x0c, 0x0d, 0x02, 0x03, 0x00, 0x01, 0x06, 0x07, 0x04, 0x05 }
};

const uint8_t tPtr[2][2] = {
    /* MixColumns temp pointer */
{   0x00, 0x01 },
{   0x02, 0x03 }
};

const uint8_t mRed[32] = {
    /* Modulo 24 lookup table */
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17
};

const uint8_t rconst[11] = {
    /* Round constant lookup table */
    0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36, 0x6c
};

/* Global variables */
uint8_t shfSIdx[32] = {
    /* Shuffled state lookup table */
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f
};

uint8_t shfOIdx[4] = {
    /* Shuffled op lookup table */
    0x00, 0x01, 0x02, 0x03
};
uint8_t _stored_key[264];               // each key is 16 byte real key and 8 byte fake key
uint8_t *_stored_ct;                    // ciphertext storage
uint8_t state[24];                      // 16 byte real state plus 8 byte fake state
uint8_t statePtrOffset = 0;             // state pointer to consider shiftRows()
uint32_t sReg;                          // 32 bit LFSR state
uint8_t m_sbox_times[4][256];           // Masked S-box times 1, 1, 2, 3

/* Jitter generator */
uint8_t jitterBox[32];//, j_idx = 0;
/*#define MICROJITTER() \
    while(jitterBox[j_idx++]) \
        j_idx &= 0x1f;*/

/* 32 bit PRNG through WELL512() by F. Panneton et. al as implemented by C. Lomont, http://lomont.org/Math/Papers/2008/Lomont_PRNG_2008.pdf */
uint16_t index = 0;
uint32_t a, b, c, d, wellState[16];
#define PRNG() \
    a = wellState[index]; \
    c = wellState[(index + 13) & 15]; \
    b = a ^ c ^ (a << 16) ^ (c << 15); \
    c = wellState[(index + 9) & 15]; \
    c ^= (c >> 11); \
    a = wellState[index] = b ^ c; \
    d = a ^ ( (a << 5) & 0xDA442D24UL ); \
    index = (index + 15) & 15; \
    a = wellState[index]; \
    sReg = wellState[index] = a ^ b ^ d ^ (a << 2) ^ (b << 18) ^ (c << 28);

// for loop unrolling to get more cycles for ches challenge, delete if not needed
uint32_t sReg_save;

#define shfSboxOp(i) \
        m = mRed[shfSIdx[i] ^ rnd[0]]; \
        times[s[0]][m] = m_sbox_times[s[0]][state[sPtr[statePtrOffset][m]]]; \
        m = mRed[shfSIdx[i] ^ rnd[1]]; \
        times[s[1]][m] = m_sbox_times[s[1]][state[sPtr[statePtrOffset][m]]]; \
        m = mRed[shfSIdx[i] ^ rnd[2]]; \
        times[s[2]][m] = m_sbox_times[s[2]][state[sPtr[statePtrOffset][m]]]; \
        m = mRed[shfSIdx[i] ^ rnd[3]]; \
        times[s[3]][m] = m_sbox_times[s[3]][state[sPtr[statePtrOffset][m]]];

#define shfMixColOp(i) \
        m = mRed[shfSIdx[i] ^ rnd[5]]; \
        temp[s[0]][m] = times[tPtr[s[0]][0]][m] ^ times[tPtr[s[0]][1]][mPtr[0][m]]; \
        m = mRed[shfSIdx[i] ^ rnd[6]]; \
        temp[s[1]][m] = times[tPtr[s[1]][0]][m] ^ times[tPtr[s[1]][1]][mPtr[0][m]];

#define shfAddRKOp(i) \
        m = mRed[shfSIdx[i] ^ rnd[0]]; \
        state[m] = pt[m & 0x0f] ^ _stored_key[m];
// end ches challenge

void aes_indep_init(void){
    /* initialize PRNG */
#ifdef ATMEL_C
    eeprom_busy_wait();
    sReg = eeprom_read_dword((uint16_t*)(0x0000));
    srandom(sReg);
    for(uint8_t i = 0; i < 16; i++)
        wellState[i] = random();
#else
    srand(time(0));
    for(uint8_t i = 0; i < 16; i++)
        wellState[i] = (rand() << 24) | (rand() << 16) | (rand() << 8) | rand();
#endif // ATMEL_C
    /* get fakeKey */
    for(uint16_t i = 16; i < 264; i += 24){
        PRNG();
        _stored_key[i + 0] = (sReg >> 24) & 0xff;
        _stored_key[i + 1] = (sReg >> 16) & 0xff;
        _stored_key[i + 2] = (sReg >> 8)  & 0xff;
        _stored_key[i + 3] =  sReg        & 0xff;
        PRNG();
        _stored_key[i + 4] = (sReg >> 24) & 0xff;
        _stored_key[i + 5] = (sReg >> 16) & 0xff;
        _stored_key[i + 6] = (sReg >> 8)  & 0xff;
        _stored_key[i + 7] =  sReg        & 0xff;
    }
#ifdef ATMEL_C
    PRNG();
    eeprom_busy_wait();
    eeprom_write_dword((uint16_t*)(0x0000), sReg);
#endif // ATMEL_C
}

void aes_indep_key(uint8_t *key){
    uint8_t rConstIdx = 0, shift = 0, j, temp, rnd_mask[4], mask[5], combMask;
    uint32_t reseed;

    /* expand real key */
        for(uint8_t i = 0; i < 16; i++)
            _stored_key[i] = key[i];

        for(uint8_t offset = 0; offset < 240; offset += 24){
            _stored_key[offset + 24] = _stored_key[offset + 0] ^ sbox_times[0][_stored_key[offset + 13]] ^ rconst[rConstIdx++];
            _stored_key[offset + 25] = _stored_key[offset + 1] ^ sbox_times[0][_stored_key[offset + 14]];
            _stored_key[offset + 26] = _stored_key[offset + 2] ^ sbox_times[0][_stored_key[offset + 15]];
            _stored_key[offset + 27] = _stored_key[offset + 3] ^ sbox_times[0][_stored_key[offset + 12]];

            for(uint8_t i = 4; i < 16; i++)
                _stored_key[offset + 24 + i] = _stored_key[offset + i] ^ _stored_key[offset + 20 + i] ;
        }
    /* Random shuffling: randomize shfSIdx[] and shfOIdx[] */
    PRNG();
    for(uint8_t i = 0; i < 32; i++){
        j = (sReg >> shift) & 0x1f;
        shift += 5;
        temp = shfSIdx[i];
        shfSIdx[i] = shfSIdx[j];
        shfSIdx[j] = temp;
        if(shift == 30){
            j = (sReg >> shift) & 0x03;
            temp = shfOIdx[i & 0x03];
            shfOIdx[i & 0x03] = shfOIdx[j];
            shfOIdx[j] = temp;
            PRNG();
            shift = 0;
        }
    }
    /* Reseed PRNG */
#ifdef ATMEL_C
    reseed = random();
    for(uint8_t i = 0; i < 16; i += 4){
        wellState[i]     = (reseed & 0x000000ff);
        wellState[i + 1] = (reseed & 0x0000ff00);
        wellState[i + 2] = (reseed & 0x00ff0000);
        wellState[i + 3] = (reseed & 0xff000000);
        reseed = random();
    }
#else
    reseed = (rand() << 24) | (rand() << 16) | (rand() << 8) | rand();
    for(uint8_t i = 0; i < 16; i += 4){
        wellState[i]     = (reseed & 0x000000ff);
        wellState[i + 1] = (reseed & 0x0000ff00);
        wellState[i + 2] = (reseed & 0x00ff0000);
        wellState[i + 3] = (reseed & 0xff000000);
        reseed = (rand() << 24) | (rand() << 16) | (rand() << 8) | rand();
    }
#endif // ATMEL_C
    /* Masking */
    j = (reseed >> 24) & 0xff;
    PRNG();
    mask[1] = sReg & 0xff;                                                                          // get mask values that are not in consecutive order

    for(uint8_t i = 0; i < 4; i++){
        PRNG();
        rnd_mask[i] = sReg & 0xff;
    }
    mask[2] = rnd_mask[j & 0x03];

    for(uint8_t i = 0; i < 4; i++){
        PRNG();
        rnd_mask[i] = sReg & 0xff;
    }
    mask[3] = rnd_mask[(j >> 2) & 0x03];

    for(uint8_t i = 0; i < 4; i++){
        PRNG();
        rnd_mask[i] = sReg & 0xff;
    }
    mask[4] = rnd_mask[(j >> 4) & 0x03];

    for(uint8_t i = 0; i < 4; i++){
        PRNG();
        rnd_mask[i] = sReg & 0xff;
    }
    mask[0] = rnd_mask[(j >> 6) & 0x03];

    combMask = mask[0] ^ mask[1] ^ mask[2] ^ mask[3] ^ mask[4];                                     // compute combined mask for re-masking before next round

    for(uint8_t i = 0; i < 16; i++)
        _stored_key[i] ^= mask[0];                                                                  // first round key bytes get mask before S-box Op
    for(uint8_t offset = 24; offset < 240; offset += 24)
        for(uint8_t i = 0; i < 16; i++)
            _stored_key[offset + i] ^= combMask;                                                    // next round key bytes get combined mask to re-mask before S-box Op
    for(uint16_t i = 240; i < 256; i++)
        _stored_key[i] ^= mask[1];                                                                  // last round key bytes get S-box mask to remove it from ciphertext

    for(uint16_t i = 0; i < 256; i++){                                                              // generate masked S-boxes
        j = i ^ mask[0];
        m_sbox_times[0][j] = sbox_times[0][i] ^ mask[1];
        m_sbox_times[1][j] = sbox_times[0][i] ^ mask[2];
        m_sbox_times[2][j] = sbox_times[1][i] ^ mask[3];
        m_sbox_times[3][j] = sbox_times[2][i] ^ mask[4];
    }
    /* fill jitterBox[] */
    PRNG();
    reseed = sReg;
    for(uint8_t i = 0; i < 16; i++){
        jitterBox[i] = reseed & 0x03;
        reseed >>= 2;
    }
    PRNG();
    reseed = sReg;
    for(uint8_t i = 16; i < 32; i++){
        jitterBox[i] = reseed & 0x03;
        reseed >>= 2;
    }

    //for(uint8_t i = 0; i < 32; i++)
        //printf("\n%i", jitterBox[i]);

    // to save the first PRNG() call in first round to get more cycles for ches challenge, delete if not needed
    PRNG();
    sReg_save = sReg;
    // end ches challenge

    PRNG();
	sReg = key[0];
}

void aes_indep_enc(uint8_t *pt){
	uint8_t times[4][24], temp[2][24], m, s[4], rnd[7], jitter;
	uint32_t *sRegAdr;

    /* initial addRoundKey() */
    rnd[0] = sReg & 0x1f;                                                                              // get random values

    // for loop unrolling to get more cycles for ches challenge, delete if not needed and uncomment next part
    shfAddRKOp(0);
    shfAddRKOp(1);
    shfAddRKOp(2);
    shfAddRKOp(3);
    shfAddRKOp(4);
    shfAddRKOp(5);
    shfAddRKOp(6);
    shfAddRKOp(7);
    shfAddRKOp(8);
    shfAddRKOp(9);
    shfAddRKOp(10);
    shfAddRKOp(11);
    shfAddRKOp(12);
    shfAddRKOp(13);
    shfAddRKOp(14);
    shfAddRKOp(15);
    shfAddRKOp(16);
    shfAddRKOp(17);
    shfAddRKOp(18);
    shfAddRKOp(19);
    shfAddRKOp(20);
    shfAddRKOp(21);
    shfAddRKOp(22);
    shfAddRKOp(23);
    shfAddRKOp(24);
    shfAddRKOp(25);
    shfAddRKOp(26);
    shfAddRKOp(27);
    shfAddRKOp(28);
    shfAddRKOp(29);
    shfAddRKOp(30);
    shfAddRKOp(31);
    // end ches challenge

    /*for(uint8_t i = 0; i < 32; i++){
        m = mRed[shfSIdx[i] ^ rnd];                                                                 // compute rand state index
        state[m] = pt[m & 0x0f] ^ _stored_key[m];                                                   // add round key, real plaintext is used for fake state
    }*/
    /* execute 9 full rounds */
	for(uint8_t keyOffset = 24; keyOffset < 240; keyOffset += 24){
        /* shiftRows() */
        statePtrOffset = (statePtrOffset + 1) & 0x03;                                               // ShiftRow Op
        /* subBytes() and mixColumns() */

        // to save the first PRNG() call in first round to get more cycles for ches challenge, delete if not needed and uncomment next part
        if(keyOffset == 24)
            sReg = sReg_save;
        else
            {PRNG();}
        // end ches challenge

        //PRNG();                                                                                   // get random values

        //rnd[0] = sReg & 0x1f; rnd[1] = (sReg >> 5) & 0x1f; rnd[2] = (sReg >> 10) & 0x1f;          // get random values on 32 bit MCU
        //rnd[3] = (sReg >> 15) & 0x1f; rnd[4] = (sReg >> 20) & 0x03;                               // get random values on 32 bit MCU
        //rnd[5] = (sReg >> 22) & 0x1f; rnd[6] = (sReg >> 27) & 0x1f;                               // get random values on 32 bit MCU

        sRegAdr = &sReg;                                                                            // get random values on 8 bit MCU
        s[0] = *sRegAdr; *sRegAdr >>= 8;
        s[1] = *sRegAdr; *sRegAdr >>= 8;
        s[2] = *sRegAdr; *sRegAdr >>= 8;
        s[3] = *sRegAdr;

        rnd[0] = 0; rnd[1] = 0; rnd[2] = 0; rnd[3] = 0;
        jitter = jitterBox[0];                                                                      // a little bit of jitter, should be annoying
        for(;jitter--;){
            rnd[0] = jitterBox[1];}

        rnd[0] ^= s[0] & 0x1f;

        jitter = jitterBox[2];
        for(;jitter--;){
            rnd[1] = jitterBox[3];}

        rnd[1] ^= s[1] & 0x1f;

        jitter = jitterBox[4];
        for(;jitter--;){
            rnd[2] = jitterBox[5];}

        rnd[2] ^= s[2] & 0x1f;

        jitter = jitterBox[6];
        for(;jitter--;){
            rnd[3] = jitterBox[7];}

        rnd[3] ^= s[3] & 0x1f;

        rnd[4] = (s[0] & 0xc0) >> 6;
        rnd[5] = ( (s[0] & 0x20) >> 1 ) | ( (s[1] & 0xe0) >> 4 ) | ( (s[2] & 0x80) >> 7 );
        rnd[6] = ( (s[2] & 0x60) >> 2 ) | ( (s[3] & 0xe0) >> 5 );
        s[0] = shfOIdx[0] ^ rnd[4]; s[1] = shfOIdx[1] ^ rnd[4];                                     // compute rand op index 1 and 2
        s[2] = shfOIdx[2] ^ rnd[4]; s[3] = shfOIdx[3] ^ rnd[4];                                     // compute rand op index 3 and 4

        // for loop unrolling to get more cycles for ches challenge, delete if not needed and uncomment next part
        shfSboxOp(0);
        shfSboxOp(1);
        shfSboxOp(2);
        shfSboxOp(3);
        shfSboxOp(4);
        shfSboxOp(5);
        shfSboxOp(6);
        shfSboxOp(7);
        shfSboxOp(8);
        shfSboxOp(9);
        shfSboxOp(10);
        shfSboxOp(11);
        shfSboxOp(12);
        shfSboxOp(13);
        shfSboxOp(14);
        shfSboxOp(15);
        shfSboxOp(16);
        shfSboxOp(17);
        shfSboxOp(18);
        shfSboxOp(19);
        shfSboxOp(20);
        shfSboxOp(21);
        shfSboxOp(22);
        shfSboxOp(23);
        shfSboxOp(24);
        shfSboxOp(25);
        shfSboxOp(26);
        shfSboxOp(27);
        shfSboxOp(28);
        shfSboxOp(29);
        shfSboxOp(30);
        shfSboxOp(31);
        // end ches challenge

        /*for(uint8_t i = 0; i < 32; i++){
            m = mRed[shfSIdx[i] ^ rnd[0]];                                                          // compute rand state index 1                                                                   // compute rand S-box Op index 1
            times[s[0]][m] = m_sbox_times[s[0]][state[sPtr[statePtrOffset][m]]];                    // S-box and mult. Op
            m = mRed[shfSIdx[i] ^ rnd[1]];                                                          // compute rand state index 1                                                                   // compute rand S-box Op index 1
            times[s[1]][m] = m_sbox_times[s[1]][state[sPtr[statePtrOffset][m]]];                    // S-box and mult. Op
            m = mRed[shfSIdx[i] ^ rnd[2]];                                                          // compute rand state index 1                                                                   // compute rand S-box Op index 1
            times[s[2]][m] = m_sbox_times[s[2]][state[sPtr[statePtrOffset][m]]];                    // S-box and mult. Op
            m = mRed[shfSIdx[i] ^ rnd[3]];                                                          // compute rand state index 1                                                                   // compute rand S-box Op index 1
            times[s[3]][m] = m_sbox_times[s[3]][state[sPtr[statePtrOffset][m]]];                    // S-box and mult. Op
        }*/
        s[0] = ( rnd[4] ^ (rnd[4] >> 1) ) & 0x01; s[1] = !s[0];                                     // compute rand op index 1 and 2

        // for loop unrolling to get more cycles for ches challenge, delete if not needed and uncomment next part
        shfMixColOp(0);
        shfMixColOp(1);
        shfMixColOp(2);
        shfMixColOp(3);
        shfMixColOp(4);
        shfMixColOp(5);
        shfMixColOp(6);
        shfMixColOp(7);
        shfMixColOp(8);
        shfMixColOp(9);
        shfMixColOp(10);
        shfMixColOp(11);
        shfMixColOp(12);
        shfMixColOp(13);
        shfMixColOp(14);
        shfMixColOp(15);
        shfMixColOp(16);
        shfMixColOp(17);
        shfMixColOp(18);
        shfMixColOp(19);
        shfMixColOp(20);
        shfMixColOp(21);
        shfMixColOp(22);
        shfMixColOp(23);
        shfMixColOp(24);
        shfMixColOp(25);
        shfMixColOp(26);
        shfMixColOp(27);
        shfMixColOp(28);
        shfMixColOp(29);
        shfMixColOp(30);
        shfMixColOp(31);
        // end ches challenge

        /*for(uint8_t i = 0; i < 32; i++){
            m = mRed[shfSIdx[i] ^ rnd[0]];                                                          // compute rand state index 1
            temp[s[0]][m] = times[tPtr[s[0]][0]][m] ^ times[tPtr[s[0]][1]][mPtr[0][m]];             // MixColumns Op
            m = mRed[shfSIdx[i] ^ rnd[1]];                                                          // compute rand state index 1
            temp[s[1]][m] = times[tPtr[s[1]][0]][m] ^ times[tPtr[s[1]][1]][mPtr[0][m]];             // MixColumns Op
        }*/

        /* we reach this point in ches challenge */

        PRNG();                                                                                     // get random values
        rnd[0] = sReg & 0x1f;                                                                       // get random values
        for(uint8_t i = 0; i < 32; i++){
            m = mRed[shfSIdx[i] ^ rnd[0]];                                                          // compute rand state index
            state[sPtr[statePtrOffset][m]] = temp[0][mPtr[1][m]] ^ temp[1][m];                      // MixColumns Op
        }
        /* addRoundKey() */
        rnd[0] = (sReg >> 16) & 0x1f;
        for(uint8_t i = 0; i < 32; i++){
            m = mRed[shfSIdx[i] ^ rnd[0]];                                                                  // compute state index
            state[sPtr[statePtrOffset][m]] = state[sPtr[statePtrOffset][m]] ^ _stored_key[keyOffset + m];   // add round key
        }
	}

    /* execute last round */
        /* shiftRows() */
        statePtrOffset = (statePtrOffset + 1) & 0x03;                                               // ShiftRow Op
        /* subBytes() */
        PRNG();                                                                                     // get random values
        rnd[0] = sReg & 0x1f;                                                                       // get random values
        for(uint8_t i = 0; i < 32; i++){
            m = mRed[shfSIdx[i] ^ rnd[0]];                                                          // compute rand state index
            state[sPtr[statePtrOffset][m]] = m_sbox_times[0][state[sPtr[statePtrOffset][m]]];       // S-box Op
        }
        /* final addRoundKey() */
        rnd[0] = (sReg >> 16) & 0x1f;                                                               // get random values
        for(uint8_t i = 0; i < 32; i++){
            m = mRed[shfSIdx[i] ^ rnd[0]];                                                          // compute rand state index
            state[sPtr[statePtrOffset][m]] = state[sPtr[statePtrOffset][m]] ^ _stored_key[240 + m]; // add round key
        }
    /* copy ciphertext */
    PRNG();                                                                                         // get random values
    rnd[0] = sReg & 0x0f;                                                                           // get random values
	for(uint8_t i = 0; i < 16; i++){
        m = i ^ rnd[0]; //not complete here, shuffling missing!                                     // compute rand state index
		pt[m] = state[sPtr[statePtrOffset][m]];
	}
}
