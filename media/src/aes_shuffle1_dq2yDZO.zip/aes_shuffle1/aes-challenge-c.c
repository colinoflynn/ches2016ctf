/*
    This file is part of the AESExplorer Example Targets
    Copyright (C) 2012 Colin O'Flynn <coflynn@newae.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdlib.h>
#include <avr/eeprom.h>
#include "aes-challenge.h"

/* WARNING: Be VERY CAREFUL includinf a c-file like this. You are likely to get variable name collisions,
            so suggest to avoid using any generic variable names within this file */
#include "aes.c"

uint8_t key1[16];
uint8_t key2[16];
uint8_t key3[16];
uint8_t key4[16];
uint8_t * _stored_ct;

void aes_indep_init(void)
{
    int seed = eeprom_read_word(0);
	srand(seed);
}

void aes_indep_key(uint8_t * key)
{
    const uint8_t M1 = 0xff;
    const uint8_t M2 = 0xaa;
    for (uint8_t i = 0; i < 16; i++){
        key1[i] = key[i];
        key2[i] = M1^key[i];
        key3[i] = M2^key[i];
        key3[i] = M1^M2^key[i];
    }
}

void aes_indep_enc(uint8_t * pt)
{
	_stored_ct = aes(pt, key1, key2, key3, key4);
    
    for (uint8_t i = 0; i < 16; i++){
        pt[i] = _stored_ct[i];
    }

    uint16_t data = random();
    eeprom_write_word(0, data);
}
