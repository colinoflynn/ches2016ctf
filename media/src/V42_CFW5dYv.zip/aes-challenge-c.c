

#include "aes-challenge.h"
#include "aes-rsm.c"

uint8_t _stored_key[16];
uint8_t * _stored_ct;

void aes_indep_init(void)
{
    ;
}

void aes_indep_key(uint8_t * key)
{
    for (uint8_t i = 0; i < 16; i++){
        _stored_key[i] = key[i];
    }
}

void aes_indep_enc(uint8_t * pt)
{
	aes_rsm_cenc(pt, _stored_key);
  
}
