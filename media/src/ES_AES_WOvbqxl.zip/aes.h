#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
typedef uint8_t byte;
void AES_Key_Gen(unsigned char RKey[11][16], unsigned char MKey[16]);
void add_RKey(unsigned char data[], unsigned char RKey[]);
void sub_Bytes(unsigned char data[], unsigned int option);
void shift_Rows(unsigned char data[]);
void shift_Rows_bertoni(unsigned char data[]);
unsigned char xtime(unsigned char data);
void mix_Columns(unsigned char data[]);
void mix_Columns_bertoni(unsigned char data[]);
void transpose(unsigned char data[]);
void round_function(unsigned char T[], unsigned char CT[]);
void AES_encrypt_original1(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16]);
void AES_encrypt_original1_Macro(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16]);
void AES_encrypt_original2(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16]);
void AES_encrypt_original2_Macro(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16]);
void AES_encrypt_Ttable(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16]);
void AES_encrypt_Ttable_Macro(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16]);
void AES_encrypt_bertoni(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16]);
void AES_encrypt_bertoni_Macro(unsigned char CT[], unsigned char PT[], unsigned char RKey[][16]);
void AES_encrypt_shuffle(unsigned char *PT,unsigned char RKey[][16],unsigned char *CT,unsigned char shuffle);