/* aes-rsm.c */

#include <string.h>
#include <stdint.h> 
#include <stdlib.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>


void initRand(void){


uint8_t state;
static uint8_t EEMEM sstate;

state = eeprom_read_byte(&sstate);
srand(state);
eeprom_write_byte(&sstate,rand());

}



void aes_rsm_core_cenc( void );


void aes_rsm_enc(void){
 	aes_rsm_core_cenc();
	return;
}

void aes_rsm_cenc(uint8_t*v,uint8_t*k)
 {
	uint8_t *__data__		= (uint8_t*) 0x0240;
	uint8_t *__key__		= (uint8_t*) 0x0250;
	uint8_t * __header__	= (uint8_t*) 0x0260;
	uint8_t * __indi__		= (uint8_t*) 0x0270;
	uint8_t * __shuffle0__	= (uint8_t*) 0x0280;
	uint8_t * __shuffle10__	= (uint8_t*) 0x0230;
	uint8_t * __pok__		= (uint8_t*) 0x0290;
	uint8_t * __offset__	= (uint8_t*) 0x0300;
	uint8_t * __reg_out__	= (uint8_t*) 0x0310;
	uint8_t i,j,tmp;

	for(i=0;i<16;i++){
		__key__[i] = k[i];
	}
	
	for(i=0;i<16;i++){
		__data__[i] = v[i];
	}

	for(i=0;i<16;i++){
		__shuffle0__[i] =i;
	}
	for(i=0;i<16;i++){
		__shuffle10__[i] =i;
	}
	initRand();

	for(i=0;i<16;i++){
	j = rand()% 16;
	tmp = __shuffle0__[j];
	__shuffle0__[j] = __shuffle0__ [15 - i];
	__shuffle0__[15 - i] = tmp;
	}

	for(i=0;i<16;i++){
	j = rand()% 16;
	tmp = __shuffle10__[j];
	__shuffle10__[j] = __shuffle10__ [15 - i];
	__shuffle10__[15 - i] = tmp;
	}


	for(i=0;i<16;i++){
		__offset__[i] = rand()% 16;
	}

/*
	//Start encryption
	aes_rsm_enc();*/

	for(i=0;i<16;i++){
		v[i] =__shuffle0__[i];
	}




}

