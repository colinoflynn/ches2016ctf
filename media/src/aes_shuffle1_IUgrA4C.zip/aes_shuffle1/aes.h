#include <stdint.h>
typedef uint8_t byte;
extern byte * aes(byte *in, byte *key1, byte *key2, byte *key3, byte *key4);
extern void addRoundKey(byte state[16], byte key[16]);
extern void subBytes(byte state[16], byte key[16]);
extern void shiftRows(byte state[16], byte key[16]);
extern byte xtime(byte x);
extern void mixColumns(byte state[16], byte key[16]);
extern void computeKey(byte rcon, byte key[16]);
