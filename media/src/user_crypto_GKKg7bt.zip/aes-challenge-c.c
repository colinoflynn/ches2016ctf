

#include "aes-challenge.h"
#include "aes-rsm.c"

uint8_t _stored_key[16];


void aes_indep_init(void)
{
   initRand() ;
}

void aes_indep_key(uint8_t * key)
{
    for (uint8_t i = 0; i < 16; i++){
        __key__[i]= key[i];
    }
	key_schedule();
	
}

void aes_indep_enc(uint8_t * pt)
{	
	uint8_t i,j,tmp;


	for(i=0;i<16;i++){
		__data__[i] = pt[i];
	}

	//Start encryption
	aes_rsm_enc();

	
	for(i=0;i<16;i++){
		pt[i] =__data__[i] ;
	}


	//Update random
	for(i=0;i<16;i++){
		__shuffle0__[i] =i;
	}
	for(i=0;i<16;i++){
		__shuffle10__[i] =i;
	}
	
	
	/*for(i=0;i<16;i++){
	j = random()&0x0F;
	tmp = __shuffle0__[j];
	__shuffle0__[j] = __shuffle0__ [15 - i];
	__shuffle0__[15 - i] = tmp;
	}

	for(i=0;i<16;i++){
	j = random()&0x0F;
	tmp = __shuffle10__[j];
	__shuffle10__[j] = __shuffle10__ [15 - i];
	__shuffle10__[15 - i] = tmp;
	}*/
	for(i=0;i<16;i++){
		__offset__[i] =7;//HWConst[random()&0x0F];

	}
}
