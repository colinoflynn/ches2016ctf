/* aes-rsm.c */

#include <string.h>
#include <stdint.h> 
#include <stdlib.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
uint8_t *__data__		= (uint8_t*) 0x3240;
uint8_t *__key__		= (uint8_t*) 0x3250;
uint8_t * __header__	= (uint8_t*) 0x3260;
uint8_t * __indi__		= (uint8_t*) 0x3270;
uint8_t * __shuffle0__	= (uint8_t*) 0x3280;
uint8_t * __shuffle10__	= (uint8_t*) 0x3230;
uint8_t * __pok__		= (uint8_t*) 0x3290;
uint8_t * __offset__	= (uint8_t*) 0x3300;
uint8_t * __reg_out__	= (uint8_t*) 0x3310;

uint8_t HWConst[16]={7,37,19,25,42,28,13,35,44,26,14,38,22,41,21,11};

void initRand(void){
uint8_t state;
static uint8_t EEMEM sstate;
uint8_t i,j,tmp;

state = eeprom_read_byte(&sstate);
srand(state);
eeprom_write_byte(&sstate,rand());
	
	for(i=0;i<16;i++){
		__shuffle0__[i] =i;
	}
	for(i=0;i<16;i++){
		__shuffle10__[i] =i;
	}
	

	for(i=0;i<16;i++){
	j = random()&0x0F;
	tmp = __shuffle0__[j];
	__shuffle0__[j] = __shuffle0__ [15 - i];
	__shuffle0__[15 - i] = tmp;
	}

	for(i=0;i<16;i++){
	j = random()&0x0F;
	tmp = __shuffle10__[j];
	__shuffle10__[j] = __shuffle10__ [15 - i];
	__shuffle10__[15 - i] = tmp;
	}


	for(i=0;i<16;i++){
		__offset__[i]= HWConst[random()&0x0F];
	}
}



void aes_rsm_core_cenc( void );
void aes_key_schedule(void);

void aes_rsm_enc(void){
 	aes_rsm_core_cenc();
	return;
}

void key_schedule(void){
 	aes_key_schedule();
	return;
}




